#!/usr/bin/env python
# coding: utf-8

# In[1]:


'''Pseudocode:
# Start
start = True

# Collect data every hour
while start:
  # Store data in Excel
  store_data_in_excel()

  # Check if the Data Collection is Complete
  data_collection_complete = check_data_collection_complete()

  # If data collection is complete, export the dataset
  if data_collection_complete:
    export_dataset()

    # Import the dataset in Python
    import_dataset()

    # Clean the dataset
    clean_dataset()

    # Analyze Energy Usage Patterns
    analyze_energy_usage_patterns()

    # Apply Optimization Technique to Reduce Energy Usage
    apply_optimization_technique()

    # Analyze the Optimized Dataset
    analyze_optimized_dataset()

    # Compare the Results Before and After Optimization
    compare_results_before_after()

    # Show the results in a Power BI dashboard
    show_results()

    # End
    start = False
    
    '''


# In[2]:


# Importing libraries: -
# Import the pandas library as pd for data manipulation and analysis.
import pandas as pd

# Import the numpy library as np for numerical operations.
import numpy as np

# Import the matplotlib library as plt for visualizations
import matplotlib.pyplot as plt 

# Importing cm from matplotlib for generating color maps for plotting.
import matplotlib.cm as cm

# Import seaborn as sns for statistics representaions
import seaborn as sns

# Import the datetime library
import datetime

# Import train_test_split to split data into training and testing sets, GridSearchCV for model tuning.
from sklearn.model_selection import train_test_split, GridSearchCV

# Import the statsmodels library as sm, which provides classes and functions for estimating and testing statistical models.
import statsmodels.api as sm

# Import LinearRegression from sklearn.linear_model for building and training linear regression models.
from sklearn.linear_model import LinearRegression

# Import DecisionTreeClassifier for building and training decision tree models.
from sklearn.tree import DecisionTreeClassifier

# Import metrics for evaluating model performance:
# - classification_report: provides detailed precision, recall, and F1-score.
# - confusion_matrix: summarizes classification accuracy.
# - mean_squared_error: measures average prediction error (lower is better).
# - r2_score: indicates how well the model explains data variance (higher is better).
from sklearn.metrics import mean_squared_error, r2_score, classification_report, confusion_matrix

# Import KMeans from sklearn.cluster to perform K-Means clustering, a method for grouping data into clusters.
from sklearn.cluster import KMeans

# Import Axes3D from mpl_toolkits.mplot3d to enable 3D plotting capabilities in matplotlib.
from mpl_toolkits.mplot3d import Axes3D

# Import the dataset from an Excel file as dt.
dt = pd.read_excel('C:/Users/ameen/OneDrive/Desktop/202000270_Final_Product/FinalProduct/EnergyProduct/EnergyDataset.xlsx')

# Print the first 5 rows of the dataset, a quick overview of the data and to test the code is working.
print("First 5 rows of the dataset:")
print(dt.head())

# Line to seperate codes
print('---------------------------------------------------------------------------------------------------------------')

# Check the structure and data types of each column
print(dt.info())


# In[3]:


# Dataset cleaning and preparation: -

# Replace empty fields, NaN values with 0.0.
dt = dt.fillna(0.0)

# Check for any remaining missing values
print(dt.isnull().sum())

print('---------------------------------------------------------------------------------------------------------------')

# Data formatting for Time attribute insted of 12 AM and 11 PM becomes 0 and 23.

# The lambda function applies strftime('%H') to each time entry, keeping only the hour portion
dt["Time"] = dt["Time"].apply(lambda x: x.strftime('%H'))

# Convert the modified Time column from string format to integer type for further analysis or plotting
dt['Time'] = dt['Time'].astype(int)

# Print dataset to confirm the changes.
print(dt)

print('---------------------------------------------------------------------------------------------------------------')

dt.to_excel("C:/Users/ameen/OneDrive/Desktop/202000270_Final_Product/FinalProduct/EnergyDashboard/CleanedEnergyDataset.xlsx", index=False)


print('---------------------------------------------------------------------------------------------------------------')


# Check the structure and data types of each column
print("Dataset Info:")
print(dt.info())

print('---------------------------------------------------------------------------------------------------------------')

# Declare variables: -
HouseID = dt["HouseID"]
Date = dt["Date"]
Time = dt["Time"]
Occupancy = dt["Occupancy"]
OutdoorTemperature = dt["OutdoorTemperature"]
AC1 = dt["AC1"]
AC2 = dt["AC2"]
AC3 = dt["AC3"]
AC4 = dt["AC4"]
AC5 = dt["AC5"]
AC6 = dt["AC6"]
AC7 = dt["AC7"]
AC8 = dt["AC8"]
TV = dt["TV"]
Refrigeter1 = dt["Refrigeter1"]
Refrigeter2 = dt["Refrigeter2"]
Refrigeter3 = dt["Refrigeter3"]
Freezer = dt["Freezer"]
VacuumCleaner = dt["VacuumCleaner"]
ClotheWasher = dt["ClotheWasher"]
ClothesDryer = dt["ClothesDryer"]
WaterDispenser = dt["WaterDispenser"]
TotalUsagekWh = dt["TotalUsagekWh"]


# In[4]:


# Aanalyze the dataset: -

# Descriptive Analysis: -

# Get summary statistics of the numerical columns : mean, median, and standard deviation
print("Summary Statistics:")
print(dt.describe())

print('---------------------------------------------------------------------------------------------------------------')

# Frequency distribution for Occupancy
occupancy_counts = dt['Occupancy'].value_counts()
print("Occupancy Frequency Distribution:")
print(occupancy_counts)


# In[5]:


# Box plot
# Create a figure and subplots with 1 row and 3 columns for displaying multiple box plots side by side
fig, ax = plt.subplots(1, 3, figsize=(15, 6))

# Adjust the spacing between the subplots for clarity and separation
plt.subplots_adjust(wspace=0.5)

# Plot a boxplot for the 'Occupancy' column in the first subplot, setting the color to brown
sns.boxplot(data=dt['Occupancy'], ax=ax[0], color='brown')
ax[0].set_title('Occupancy')  # Set the title for the first subplot
ax[0].set_xlabel('Occupancy')  # Set the label for the x-axis of the first subplot

# Plot a boxplot for 'OutdoorTemperature' in the second subplot, setting the color to red
sns.boxplot(data=dt['OutdoorTemperature'], ax=ax[1], color='Red')
ax[1].set_title('Outdoor Temperature')  # Set the title for the second subplot
ax[1].set_xlabel('Outdoor Temperature')  # Set the label for the x-axis of the second subplot

# Plot a boxplot for 'TotalUsagekWh' in the third subplot, setting the color to green
sns.boxplot(data=dt['TotalUsagekWh'], ax=ax[2], color='Green')
ax[2].set_title('Total Usage (kWh)')  # Set the title for the third subplot
ax[2].set_xlabel('Total Usage (kWh)')  # Set the label for the x-axis of the third subplot

# Display the created box plots on the screen
plt.show()

print('---------------------------------------------------------------------------------------------------------------')

# Create a pair plot to visualize the relationship between 'Occupancy' and 'OutdoorTemperature' 
# with respect to 'TotalUsagekWh'. This scatter plot will help to identify any trends or 
# correlations between the number of occupants and the outdoor temperature on energy consumption.

sns.pairplot(dt, x_vars=['Occupancy','OutdoorTemperature','Time'], y_vars='TotalUsagekWh', height = 4, kind = 'scatter')
plt.show()


# In[6]:


# Show minimum Energy Usage details

# Find the row with minimum energy usage
min_usage_row = dt.loc[dt['TotalUsagekWh'].idxmin()]

# Print the details for the minimum energy usage
print("Minimum Energy Usage:")
print(f"The hour: {min_usage_row['Time']}")
print(f"Day: {min_usage_row['Date']}")
print(f"Total Usage (kWh): {min_usage_row['TotalUsagekWh']}")
print(f"Temperature: {min_usage_row['OutdoorTemperature']}")
print(f"Occupancy: {min_usage_row['Occupancy']}")

# Minimum Energy Usage: The lowest energy consumption was recorded in the evening at 6:00 PM on October 15th, 
# under warm conditions (31°C) with 3 people present.

print('---------------------------------------------------------------------------------------------------------------')


# Show maximum Energy Usage details

# Find the row with maximum energy usage
max_usage_row = dt.loc[dt['TotalUsagekWh'].idxmax()]

# Print the details for the maximum energy usage
print("\nMaximum Energy Usage:")
print(f"The hour: {max_usage_row['Time']}")
print(f"Day: {max_usage_row['Date']}")
print(f"Total Usage (kWh): {max_usage_row['TotalUsagekWh']}")
print(f"Temperature: {max_usage_row['OutdoorTemperature']}")
print(f"Occupancy: {max_usage_row['Occupancy']}")

# Maximum Energy Usage: The highest energy consumption occurred in the late morning at 10:00 AM on October 18th, 
# with a higher temperature of 34°C and 4 people present.


# In[7]:


# Inferential Analysis

#Correlation Analysis

#Heatmap for correlations matrix
plt.figure(figsize=(26, 16))  # Increase width and height for better visibility

# Create a heatmap using the correlation matrix
sns.heatmap(dt.corr(), annot=True, cmap='RdBu', linewidths=1, linecolor='Brown', vmin=-1, vmax=1)

# Display the heatmap
plt.show()

print('---------------------------------------------------------------------------------------------------------------')

# Regression model measure relationships between variables
# Highest Positive Relationships: -
# x Independent variable
x = dt['Time']
# y Dependent variable
y = dt['TV']

# Split the dataset into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.7, test_size=0.3, random_state=100)

# Add a constant to the model (intercept)
x_train = sm.add_constant(x_train)

# Fit the OLS regression model
LR = sm.OLS(y_train, x_train).fit()

# Print the summary of the regression model
print(LR.summary())

print('---------------------------------------------------------------------------------------------------------------')
# Highest Negative Relationships:

# x Independent variable
x = dt['Time'] 
# y Dependent variable
y = dt['AC3']

# Split the dataset into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.7, test_size=0.3, random_state=100)

# Add a constant to the model (intercept)
x_train = sm.add_constant(x_train)

# Fit the OLS regression model
LR = sm.OLS(y_train, x_train).fit()

# Print the summary of the regression model
print(LR.summary())


# In[8]:


# Calculate the covariance matrix
cov_matrix = dt.cov()
# Create a custom diverging color palette for blue positive and red negative
cmap = sns.diverging_palette(10, 240, as_cmap=True)  # This reverses the colors to make positive blue and negative red
# Set the figure size for the plot to ensure readability
plt.figure(figsize=(20, 17))
# Create a heatmap for visualizing the covariance matrix
sns.heatmap(
    cov_matrix,  # The covariance matrix data
    annot=True,  # Display the covariance values in the heatmap cells
    cmap=cmap,  # Use the modified color map for positive (blue) and negative (red)
    linewidths=1,  # Add lines between cells for better separation
    fmt=".2f",  # Format the displayed values to show 2 decimal places
    center=0,  # Center the color map at zero, so 0.0 appears white
    cbar_kws={"shrink": 0.5}  # Shrink the color bar to fit the plot better
)

# Add a title to the heatmap for context
plt.title('Covariance Matrix Heatmap')
# Display the heatmap plot
plt.show()


# In[9]:


#Time Series Analysis
# Plot total usage over time to identify trends and patterns.
# Create 'Datetime' column and set it as the index
dt['Datetime'] = pd.to_datetime(dt['Date'] + ' ' + dt['Time'].astype(str) + ':00:00', dayfirst=True)
dt.set_index('Datetime', inplace=True)

# Get unique days and generate a color map for distinct visualization
unique_days = dt['Date'].unique()
colors = cm.rainbow(np.linspace(0, 1, len(unique_days)))  # Create distinct colors for each day

plt.figure(figsize=(14, 7))

# Plot each day's data with a unique color for the lines and points
for i, day in enumerate(unique_days):
    daily_data = dt[dt['Date'] == day]  # Extract data for the specific day
    day_name = pd.to_datetime(day, dayfirst=True).strftime('%A')  # Convert to day name (e.g., 'Sunday')
    plt.plot(daily_data.index, daily_data['TotalUsagekWh'], marker='o', color=colors[i], label=day_name, linestyle='-')

    # If not the last day, connect the end of this day's line to the start of the next with a solid black line
    if i < len(unique_days) - 1:
        next_day_data = dt[dt['Date'] == unique_days[i + 1]]
        if not daily_data.empty and not next_day_data.empty:
            plt.plot(
                [daily_data.index[-1], next_day_data.index[0]],
                [daily_data['TotalUsagekWh'].iloc[-1], next_day_data['TotalUsagekWh'].iloc[0]],
                color='black', linestyle='-'  # Solid black line connecting two different days
            )

# Add plot title and labels for better context
plt.title('Time Series Analysis of Total Energy Usage (kWh) for Each Day')
plt.xlabel('Time')
plt.ylabel('Total Usage (kWh)')
plt.legend(loc='upper right', bbox_to_anchor=(1.15, 1))  # Adjust legend position
plt.grid(True)  # Add grid lines for readability
plt.show()  # Display the plot


# In[10]:


# Energy Usage by Appliance Analysis

# List of appliances in your dataset
appliances = [
    "AC1", "AC2", "AC3", "AC4", "AC5", "AC6", "AC7", "AC8", 'Refrigeter1', 'Refrigeter2', 'Refrigeter3', 'Freezer',
    "TV", "VacuumCleaner", "ClotheWasher", "ClothesDryer", "WaterDispenser"
]

# Calculate total energy usage for each appliance
total_usage_per_appliance = dt[appliances].sum()

# Calculate percentage contribution for each appliance
percentage_contribution = (total_usage_per_appliance / total_usage_per_appliance.sum()) * 100

# Plot total energy usage per appliance
plt.figure(figsize=(12, 8))
total_usage_per_appliance.plot(kind='bar', color='red')
plt.title('Total Energy Usage per Appliance')
plt.xlabel('Appliance')
plt.ylabel('Total Usage (kWh)')
plt.xticks(rotation=45, ha='right')  # Rotate x labels for better readability
plt.show()


# In[11]:


# Identify clusters
# Create new features by aggregating device usage into broader categories
dt['TotalACUsage'] = (
    dt['AC1'] + dt['AC2'] + dt['AC3'] + dt['AC4'] + 
    dt['AC5'] + dt['AC6'] + dt['AC7'] + dt['AC8']
)

# Group refrigerators, freezers, and water dispensers into CoolingDevices
dt['TotalCoolingDevicesUsage'] = (
    dt['Refrigeter1'] + dt['Refrigeter2'] + dt['Refrigeter3'] + 
    dt['Freezer'] + dt['WaterDispenser']
)

# Group cleaning devices together
dt['TotalCleaningDevicesUsage'] = (
    dt['VacuumCleaner'] + dt['ClotheWasher'] + 
    dt['ClothesDryer']
)

# Define the features for clustering
features = ['TotalACUsage', 'TotalCoolingDevicesUsage', 'TotalCleaningDevicesUsage']
dt_selected = dt[features].dropna()  # Remove any rows with missing values for clustering

# Applying K-Means Clustering
kmeans = KMeans(n_clusters=3, random_state=42)  # Adjust number of clusters as needed
dt_selected['Cluster'] = kmeans.fit_predict(dt_selected)

# Aggregating usage for each device group by hour
hourly_ac_usage = dt.groupby('Time')['TotalACUsage'].sum()
hourly_cooling_usage = dt.groupby('Time')['TotalCoolingDevicesUsage'].sum()
hourly_cleaning_usage = dt.groupby('Time')['TotalCleaningDevicesUsage'].sum()

# Plotting hourly usage for comparison
plt.figure(figsize=(10, 6))
plt.plot(hourly_ac_usage.index, hourly_ac_usage, label='AC Devices', marker='o', color='blue')
plt.plot(hourly_cooling_usage.index, hourly_cooling_usage, label='Cooling Devices', marker='o', color='green')
plt.plot(hourly_cleaning_usage.index, hourly_cleaning_usage, label='Cleaning Devices', marker='o', color='red')

# Labeling
plt.xlabel('Hour of the Day')
plt.ylabel('Total Usage (kWh)')
plt.title('Hourly Energy Usage Patterns by Device Category')
plt.xticks(range(0, 24, 1))  # Show all hours on the x-axis
plt.legend()
plt.grid(True)
plt.show()


# In[12]:


# Classification Analysis:
# Categorize 'TotalUsageKWh' into 'Low', 'Medium', and 'High' usage levels.
dt['UsageCategory'] = pd.cut(dt['TotalUsagekWh'], bins=[0, 5, 10, dt['TotalUsagekWh'].max()], 
                             labels=['Low', 'Medium', 'High'])

# Prepare the feature set (X) with appliance data and relevant variables.
X = dt[['Time', 'OutdoorTemperature', 'AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8',
        'TV', 'Refrigeter1', 'Refrigeter2', 'Refrigeter3', 'Freezer',
        'VacuumCleaner', 'ClotheWasher', 'ClothesDryer', 'WaterDispenser']]
# Define the target variable (y) as the categorized energy usage.
y = dt['UsageCategory']

# Split the dataset into training and testing sets (70% train, 30% test).
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Initialize the Decision Tree Classifier for classification.
classifier = DecisionTreeClassifier(random_state=42)

# Set up a hyperparameter grid for tuning the Decision Tree Classifier using GridSearchCV.
param_grid = {
    'max_depth': [None, 5, 10, 15],  # Varying tree depth for complexity control.
    'min_samples_split': [2, 5, 10],  # Minimum samples required to split a node.
    'min_samples_leaf': [1, 2, 5]  # Minimum samples required for a leaf node.
}

# Perform GridSearchCV for the best combination of hyperparameters.
grid_search = GridSearchCV(estimator=classifier, param_grid=param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train, y_train)

# Display the optimal hyperparameters found.
print("Best parameters found: ", grid_search.best_params_)

# Use the best estimator from GridSearchCV to make predictions.
best_classifier = grid_search.best_estimator_
y_pred = best_classifier.predict(X_test)

# Print the classification report summarizing precision, recall, and F1-score.
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print('---------------------------------------------------------------------------------------------------------------')

# Create and display a confusion matrix to visualize prediction results.
conf_matrix = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, cmap='Blues', fmt='d', 
            xticklabels=['Low', 'Medium', 'High'], yticklabels=['Low', 'Medium', 'High'])
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()


# In[13]:


# Data summarization before optimization 
# Loop through each specified appliance to determine daily usage patterns
for appliance in ['AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8', 'TV',
                  'VacuumCleaner', 'ClotheWasher', 'ClothesDryer']:
    print(f"\n{appliance}:")  # Print the appliance name to start its usage summary
    
    # Iterate through each unique date in the dataset to check appliance usage on each day
    for date in dt['Date'].unique():
        # Get a list of the specific hours when the appliance was running on the current date
        hours_running = dt[(dt['Date'] == date) & (dt[appliance] > 0)]['Time'].tolist()
        
        # If the appliance was running at any hour(s) on this date, print those hours
        if hours_running:
            print(f"  {date} - Run at hour(s): {', '.join(map(str, hours_running))}")
        else:
            # If the appliance did not run on this date, indicate it was "Not running"
            print(f"  {date} - Not running")

# Calculate and display the total energy usage for each day
# Group data by 'Date' and calculate the sum of 'TotalUsagekWh' for each day to get daily usage totals
total_usage_per_day = dt.groupby('Date')['TotalUsagekWh'].sum()

print("\nTotal Energy Usage for Each Day:")
# Iterate over the calculated daily usage totals and print each date’s total energy consumption
for date, total_usage in total_usage_per_day.items():
    print(f"Date: {date}, Total Usage: {total_usage:.2f} kWh")  # Display usage to two decimal places for clarity

# Calculate and display the total energy usage across all days
# Sum up the total daily energy usage to get a cumulative total for the entire period
total_usage_all_days = total_usage_per_day.sum()
print(f"\nTotal Energy Usage Across All Days: {total_usage_all_days:.2f} kWh")  # Display grand total energy usage


# In[14]:


# Install the PuLP library, which is a Python library used for linear programming and optimization.


# In[15]:


pip install pulp


# In[16]:


# Optimization technique: Linear programming

# Import necessary components from PuLP for linear programming:
# - LpMinimize: Specifies a minimization objective, used to reduce total energy usage.
# - LpProblem: Establishes the optimization model with defined objectives and constraints.
# - LpVariable: Creates decision variables for each device’s on/off state in each time slot.
# - lpSum: Calculates the total power consumption, used in the objective and constraint expressions.
from pulp import LpMinimize, LpProblem, LpVariable, lpSum

# Dictionary to define power consumption values (in kWh) for each device we aim to optimize.
power_consumption = {
    'AC1': 3.4, 'AC2': 1.83, 'AC3': 3.4, 'AC4': 2, 'AC5': 1.98, 'AC6': 2.08,
    'AC7': 2.12, 'AC8': 2.12, 'TV': 0.27, 'VacuumCleaner': 1, 'ClotheWasher': 0.41, 'ClothesDryer': 2.7
}

# Dictionary for devices that are constantly on, with their fixed power usage.
always_on_devices = {
    'Refrigeter1': 0.5, 'Refrigeter2': 0.5, 'Refrigeter3': 0.3, 
    'Freezer': 0.0354, 'WaterDispenser': 0.94
}

# Assume dt is your DataFrame containing the dataset.
# Extract only the necessary columns from the DataFrame for optimization processing.
original_columns = [
    'HouseID', 'Date', 'Time', 'Occupancy', 'OutdoorTemperature',
    'AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8', 'TV',
    'Refrigeter1', 'Refrigeter2', 'Refrigeter3', 'Freezer',
    'VacuumCleaner', 'ClotheWasher', 'ClothesDryer', 'WaterDispenser'
]
dtOptimize = dt[original_columns]
dtOptimize['DateTime'] = pd.to_datetime(dtOptimize['Date'], format='%d/%m/%Y')

# Function to optimize energy usage for a single row of data.
def optimize_energy(row, daily_tv_usage):
    # Extract relevant parameters for setting constraints.
    outdoor_temperature = row['OutdoorTemperature']
    time_of_day = row['Time']
    day_of_week = row['DateTime'].day_name()

    # Define an optimization model aimed at minimizing energy usage.
    model = LpProblem("Minimize_Energy_Usage", LpMinimize)
    
    # Create binary decision variables for each device; 1 if the device is on, 0 if off.
    devices = {device: LpVariable(device, cat="Binary") for device in power_consumption}

    # Objective function: Minimize the total energy usage of active devices.
    model += lpSum(devices[device] * power for device, power in power_consumption.items()), "Total_Energy_Usage"

    # Conditional constraints for device operation based on temperature and other conditions:
    # Temperature constraint: AC will be 0 if temperature between 25-29°C range.
    ac_devices = ['AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8']
    if 25 <= outdoor_temperature <= 29:
        # Turn off all ACs if temperature is in the specified range.
        for ac in ac_devices:
            model += devices[ac] == 0
    else:
        # If outside the range, AC usage is the same.
        for ac in ac_devices:
            model += devices[ac] == (1 if row[ac] > 0 else 0)

    # TV constraint: Limit TV usage to 4 hours per day.
    if daily_tv_usage < 4 and row['TV'] > 0:
        model += devices['TV'] == 1  # TV can be on if daily usage is below the limit.
    else:
        model += devices['TV'] == 0  # TV remains off if usage limit is reached.

    # Vacuum cleaner constraint: Only use on specific days and times.
    if day_of_week in ["Tuesday", "Thursday", "Saturday"] and time_of_day == 7:
        model += devices['VacuumCleaner'] == 1  # Vacuum cleaner can be on.
    else:
        model += devices['VacuumCleaner'] == 0  # Vacuum cleaner remains off otherwise.

    # Laundry constraints: ClotheWasher and ClothesDryer operate only on specified days and times.
    if day_of_week in ["Sunday", "Tuesday", "Thursday"]:
        model += devices['ClotheWasher'] == (1 if time_of_day == 10 else 0)
        model += devices['ClothesDryer'] == (1 if time_of_day == 12 else 0)
    else:
        model += devices['ClotheWasher'] == 0
        model += devices['ClothesDryer'] == 0

    # Solve the optimization problem and retrieve results.
    model.solve()
    # Store optimized values for each device, including constant devices that are always on.
    optimized_values = {device: int(devices[device].varValue) * power_consumption[device] for device in devices}
    optimized_values.update(always_on_devices)  # Add constant devices' power usage.
    return optimized_values

# Apply optimization function to each row of data and update daily TV usage.
for date, group in dtOptimize.groupby('DateTime'):
    daily_tv_usage = 0  # Track daily TV usage per day.
    for index, row in group.iterrows():
        # Get optimized energy usage for the row.
        optimized_values = optimize_energy(row, daily_tv_usage)
        # Update daily TV usage counter if TV is on in this row.
        if optimized_values['TV'] > 0:
            daily_tv_usage += 1
        # Write optimized values back into the DataFrame.
        for device, value in optimized_values.items():
            dtOptimize.at[index, device] = value

# Occupancy constraint: Adjust device usage according to occupancy values.
ac_columns = ['AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8']
for index, row in dtOptimize.iterrows():
    occupancy = row['Occupancy']
    # If no one is home, set certain devices to 0 to save energy.
    if occupancy == 0:
        dtOptimize.loc[index, ac_columns + ['TV', 'VacuumCleaner']] = 0.0
    else:
        # Limit the number of active ACs to match occupancy level.
        active_acs = [ac for ac in ac_columns if row[ac] > 0]
        if len(active_acs) > occupancy:
            for ac in active_acs[occupancy:]:
                dtOptimize.at[index, ac] = 0.0

# Calculate the total energy usage for each row and store it in a new column.
usage_columns = [
    'AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8', 'TV',
    'VacuumCleaner', 'ClotheWasher', 'ClothesDryer',
    'Refrigeter1', 'Refrigeter2', 'Refrigeter3', 'Freezer', 'WaterDispenser'
]
dtOptimize['TotalUsagekWh'] = dtOptimize[usage_columns].sum(axis=1)

# Finalize dataset by selecting relevant columns and exporting to an Excel file.
final_columns = original_columns + ['TotalUsagekWh']
dtNewDataset = dtOptimize[final_columns]
dtNewDataset.to_excel("C:/Users/ameen/OneDrive/Desktop/202000270_Final_Product/FinalProduct/EnergyProduct/OptimizedEnergyUsageDataset.xlsx", index=False)
print("Optimized dataset saved as 'OptimizedEnergyUsageDataset.xlsx'")


# In[17]:


# view of the optimized dataset
print(dtNewDataset)

print('---------------------------------------------------------------------------------------------------------------')

# Check the structure and data types of each column for the optimized dataset
print(dt.info())


# In[18]:


# Declare variables for dtNewDataset where L stands for Linear programming: -
LHouseID = dtNewDataset["HouseID"]
LDate = dtNewDataset["Date"]
LTime = dtNewDataset["Time"]
LOccupancy = dtNewDataset["Occupancy"]
LOutdoorTemperature = dtNewDataset["OutdoorTemperature"]
LAC1 = dtNewDataset["AC1"]
LAC2 = dtNewDataset["AC2"]
LAC3 = dtNewDataset["AC3"]
LAC4 = dtNewDataset["AC4"]
LAC5 = dtNewDataset["AC5"]
LAC6 = dtNewDataset["AC6"]
LAC7 = dtNewDataset["AC7"]
LAC8 = dtNewDataset["AC8"]
LTV = dtNewDataset["TV"]
LRefrigeter1 = dtNewDataset["Refrigeter1"]
LRefrigeter2 = dtNewDataset["Refrigeter2"]
LRefrigeter3 = dtNewDataset["Refrigeter3"]
LFreezer = dtNewDataset["Freezer"]
LVacuumCleaner = dtNewDataset["VacuumCleaner"]
LClotheWasher = dtNewDataset["ClotheWasher"]
LClothesDryer = dtNewDataset["ClothesDryer"]
LWaterDispenser = dtNewDataset["WaterDispenser"]
LTotalUsagekWh = dtNewDataset["TotalUsagekWh"]


# In[19]:


# Aanalyze the optimized dataset: -

# Descriptive Analysis: -

# Get summary statistics of the numerical columns : mean, median, and standard deviation
print("Summary Statistics:")
print(dtNewDataset.describe())


# In[20]:


# Box plot after optimization
# Create a figure and subplots with 1 row and 3 columns for displaying multiple box plots side by side
fig, ax = plt.subplots(1, 3, figsize=(15, 6))

# Adjust the spacing between the subplots for clarity and separation
plt.subplots_adjust(wspace=0.5)

# Plot a boxplot for the 'Occupancy' column in the first subplot, setting the color to brown
sns.boxplot(data=dtNewDataset['Occupancy'], ax=ax[0], color='brown')
ax[0].set_title('Occupancy')  # Set the title for the first subplot
ax[0].set_xlabel('Occupancy')  # Set the label for the x-axis of the first subplot

# Plot a boxplot for 'OutdoorTemperature' in the second subplot, setting the color to red
sns.boxplot(data=dtNewDataset['OutdoorTemperature'], ax=ax[1], color='Red')
ax[1].set_title('Outdoor Temperature')  # Set the title for the second subplot
ax[1].set_xlabel('Outdoor Temperature')  # Set the label for the x-axis of the second subplot

# Plot a boxplot for 'TotalUsagekWh' in the third subplot, setting the color to green
sns.boxplot(data=dtNewDataset['TotalUsagekWh'], ax=ax[2], color='Green')
ax[2].set_title('Total Usage (kWh)')  # Set the title for the third subplot
ax[2].set_xlabel('Total Usage (kWh)')  # Set the label for the x-axis of the third subplot

# Display the created box plots on the screen
plt.show()


# In[21]:


# After optimization
# Show minimum Energy Usage details

# Find the row with minimum energy usage
min_usage_row = dtNewDataset.loc[dtNewDataset['TotalUsagekWh'].idxmin()]

# Print the details for the minimum energy usage
print("Minimum Energy Usage:")
print(f"The hour: {min_usage_row['Time']}")
print(f"Day: {min_usage_row['Date']}")
print(f"Total Usage (kWh): {min_usage_row['TotalUsagekWh']}")
print(f"Temperature: {min_usage_row['OutdoorTemperature']}")
print(f"Occupancy: {min_usage_row['Occupancy']}")

# Minimum Energy Usage: The lowest energy consumption was recorded at 3 AM on October 13th, 
# under comfortable conditions (29°C) with 4 people present.

print('---------------------------------------------------------------------------------------------------------------')


# Show maximum Energy Usage details

# Find the row with maximum energy usage
max_usage_row = dtNewDataset.loc[dtNewDataset['TotalUsagekWh'].idxmax()]

# Print the details for the maximum energy usage
print("\nMaximum Energy Usage:")
print(f"The hour: {max_usage_row['Time']}")
print(f"Day: {max_usage_row['Date']}")
print(f"Total Usage (kWh): {max_usage_row['TotalUsagekWh']}")
print(f"Temperature: {max_usage_row['OutdoorTemperature']}")
print(f"Occupancy: {max_usage_row['Occupancy']}")

# Maximum Energy Usage: The highest energy consumption occurred in the at Midnight on October 19th, 
# with a higher temperature of 29.8°C and 5 people present.


# In[22]:


# After optimization
# Inferential Analysis

# Correlation Analysis

# Heatmap for correlations matrix
plt.figure(figsize=(20, 14))  # Increase width and height for better visibility

# Create a heatmap using the correlation matrix with scale ranging from -1 to 1
sns.heatmap(dtNewDataset.corr(), annot=True, cmap='RdBu', linewidths=1, linecolor='Brown', vmin=-1, vmax=1)

# Display the heatmap
plt.show()

print('---------------------------------------------------------------------------------------------------------------')

# Regression model measure relationships between variables
# Highest Positive Relationships: -
# x Independent variable
x = dtNewDataset['AC3']
# y Dependent variable
y = dtNewDataset['TotalUsagekWh']

# Split the dataset into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.7, test_size=0.3, random_state=100)

# Add a constant to the model (intercept)
x_train = sm.add_constant(x_train)

# Fit the OLS regression model
LR = sm.OLS(y_train, x_train).fit()

# Print the summary of the regression model
print(LR.summary())


# In[23]:


# Calculate the covariance matrix
cov_matrix = dtNewDataset.cov()
# Create a custom diverging color palette for blue positive and red negative
cmap = sns.diverging_palette(10, 240, as_cmap=True)  # This reverses the colors to make positive blue and negative red
# Set the figure size for the plot to ensure readability
plt.figure(figsize=(20, 17))
# Create a heatmap for visualizing the covariance matrix
sns.heatmap(
    cov_matrix,  # The covariance matrix data
    annot=True,  # Display the covariance values in the heatmap cells
    cmap=cmap,  # Use the modified color map for positive (blue) and negative (red)
    linewidths=1,  # Add lines between cells for better separation
    fmt=".2f",  # Format the displayed values to show 2 decimal places
    center=0,  # Center the color map at zero, so 0.0 appears white
    cbar_kws={"shrink": 0.5}  # Shrink the color bar to fit the plot better
)

# Add a title to the heatmap for context
plt.title('Covariance Matrix Heatmap')
# Display the heatmap plot
plt.show()


# In[24]:


#Time Series Analysis
# Plot total usage over time to identify trends and patterns.
# Create 'Datetime' column and set it as the index
dtNewDataset['Datetime'] = pd.to_datetime(dtNewDataset['Date'] +
                                          ' ' + dtNewDataset['Time'].astype(str) + ':00:00', dayfirst=True)
dtNewDataset.set_index('Datetime', inplace=True)

# Get unique days and generate a color map for distinct visualization
unique_days = dtNewDataset['Date'].unique()
colors = cm.rainbow(np.linspace(0, 1, len(unique_days)))  # Create distinct colors for each day

plt.figure(figsize=(14, 7))

# Plot each day's data with a unique color for the lines and points
for i, day in enumerate(unique_days):
    daily_data = dtNewDataset[dt['Date'] == day]  # Extract data for the specific day
    day_name = pd.to_datetime(day, dayfirst=True).strftime('%A')  # Convert to day name (e.g., 'Sunday')
    plt.plot(daily_data.index, daily_data['TotalUsagekWh'], marker='o', color=colors[i], label=day_name, linestyle='-')

    # If not the last day, connect the end of this day's line to the start of the next with a solid black line
    if i < len(unique_days) - 1:
        next_day_data = dtNewDataset[dtNewDataset['Date'] == unique_days[i + 1]]
        if not daily_data.empty and not next_day_data.empty:
            plt.plot(
                [daily_data.index[-1], next_day_data.index[0]],
                [daily_data['TotalUsagekWh'].iloc[-1], next_day_data['TotalUsagekWh'].iloc[0]],
                color='black', linestyle='-'  # Solid black line connecting two different days
            )

# Add plot title and labels for better context
plt.title('Time Series Analysis of Total Energy Usage (kWh) for Each Day')
plt.xlabel('Time')
plt.ylabel('Total Usage (kWh)')
plt.legend(loc='upper right', bbox_to_anchor=(1.15, 1))  # Adjust legend position
plt.grid(True)  # Add grid lines for readability
plt.show()  # Display the plot


# In[25]:


# Energy Usage by Appliance Analysis

# List of appliances in your dataset
appliances = [
    "AC1", "AC2", "AC3", "AC4", "AC5", "AC6", "AC7", "AC8", 'Refrigeter1', 'Refrigeter2', 'Refrigeter3', 'Freezer',
    "TV", "VacuumCleaner", "ClotheWasher", "ClothesDryer", "WaterDispenser"
]

# Calculate total energy usage for each appliance
total_usage_per_appliance = dtNewDataset[appliances].sum()

# Calculate percentage contribution for each appliance
percentage_contribution = (total_usage_per_appliance / total_usage_per_appliance.sum()) * 100

# Plot total energy usage per appliance
plt.figure(figsize=(12, 8))
total_usage_per_appliance.plot(kind='bar', color='red')
plt.title('Total Energy Usage per Appliance')
plt.xlabel('Appliance')
plt.ylabel('Total Usage (kWh)')
plt.xticks(rotation=45, ha='right')  # Rotate x labels for better readability
plt.show()


# In[26]:


# Identify clusters
# Create new features by aggregating device usage into broader categories
dtNewDataset['TotalACUsage'] = (
    dtNewDataset['AC1'] + dtNewDataset['AC2'] + dtNewDataset['AC3'] + dtNewDataset['AC4'] + 
    dtNewDataset['AC5'] + dtNewDataset['AC6'] + dtNewDataset['AC7'] + dtNewDataset['AC8']
)

# Group refrigerators, freezers, and water dispensers into CoolingDevices
dtNewDataset['TotalCoolingDevicesUsage'] = (
    dtNewDataset['Refrigeter1'] + dtNewDataset['Refrigeter2'] + dtNewDataset['Refrigeter3'] + 
    dtNewDataset['Freezer'] + dtNewDataset['WaterDispenser']
)

# Group cleaning devices together
dtNewDataset['TotalCleaningDevicesUsage'] = (
    dtNewDataset['VacuumCleaner'] + dtNewDataset['ClotheWasher'] + 
    dtNewDataset['ClothesDryer']
)

# Define the features for clustering
features = ['TotalACUsage', 'TotalCoolingDevicesUsage', 'TotalCleaningDevicesUsage']
dt_selected = dtNewDataset[features].dropna()  # Remove any rows with missing values for clustering

# Applying K-Means Clustering
kmeans = KMeans(n_clusters=3, random_state=42)  # Adjust number of clusters as needed
dt_selected['Cluster'] = kmeans.fit_predict(dt_selected)

# Aggregating usage for each device group by hour
hourly_ac_usage = dtNewDataset.groupby('Time')['TotalACUsage'].sum()
hourly_cooling_usage = dtNewDataset.groupby('Time')['TotalCoolingDevicesUsage'].sum()
hourly_cleaning_usage = dtNewDataset.groupby('Time')['TotalCleaningDevicesUsage'].sum()

# Plotting hourly usage for comparison
plt.figure(figsize=(10, 6))
plt.plot(hourly_ac_usage.index, hourly_ac_usage, label='AC Devices', marker='o', color='blue')
plt.plot(hourly_cooling_usage.index, hourly_cooling_usage, label='Cooling Devices', marker='o', color='green')
plt.plot(hourly_cleaning_usage.index, hourly_cleaning_usage, label='Cleaning Devices', marker='o', color='red')

# Labeling
plt.xlabel('Hour of the Day')
plt.ylabel('Total Usage (kWh)')
plt.title('Hourly Energy Usage Patterns by Device Category')
plt.xticks(range(0, 24, 1))  # Show all hours on the x-axis
plt.legend()
plt.grid(True)
plt.show()


# In[27]:


# Classification Analysis:
# Categorize 'TotalUsageKWh' into 'Low', 'Medium', and 'High' usage levels.
dtNewDataset['UsageCategory'] = pd.cut(dtNewDataset['TotalUsagekWh'], bins=[0, 5, 10, dtNewDataset['TotalUsagekWh'].max()], 
                             labels=['Low', 'Medium', 'High'])

# Prepare the feature set (X) with appliance data and relevant variables.
X = dtNewDataset[['Time', 'OutdoorTemperature', 'AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8',
        'TV', 'Refrigeter1', 'Refrigeter2', 'Refrigeter3', 'Freezer',
        'VacuumCleaner', 'ClotheWasher', 'ClothesDryer', 'WaterDispenser']]
# Define the target variable (y) as the categorized energy usage.
y = dtNewDataset['UsageCategory']

# Split the dataset into training and testing sets (70% train, 30% test).
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Initialize the Decision Tree Classifier for classification.
classifier = DecisionTreeClassifier(random_state=42)

# Set up a hyperparameter grid for tuning the Decision Tree Classifier using GridSearchCV.
param_grid = {
    'max_depth': [None, 5, 10, 15],  # Varying tree depth for complexity control.
    'min_samples_split': [2, 5, 10],  # Minimum samples required to split a node.
    'min_samples_leaf': [1, 2, 5]  # Minimum samples required for a leaf node.
}

# Perform GridSearchCV for the best combination of hyperparameters.
grid_search = GridSearchCV(estimator=classifier, param_grid=param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train, y_train)

# Display the optimal hyperparameters found.
print("Best parameters found: ", grid_search.best_params_)

# Use the best estimator from GridSearchCV to make predictions.
best_classifier = grid_search.best_estimator_
y_pred = best_classifier.predict(X_test)

# Print the classification report summarizing precision, recall, and F1-score.
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print('---------------------------------------------------------------------------------------------------------------')

# Create and display a confusion matrix to visualize prediction results.
conf_matrix = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, cmap='Blues', fmt='d', 
            xticklabels=['Low', 'Medium', 'High'], yticklabels=['Low', 'Medium', 'High'])
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()


# In[28]:


# Data summarization for the optimized dataset
# Loop through each specified appliance to summarize daily usage patterns.
for appliance in ['AC1', 'AC2', 'AC3', 'AC4', 'AC5', 'AC6', 'AC7', 'AC8', 'TV',
                  'VacuumCleaner', 'ClotheWasher', 'ClothesDryer']:
    print(f"\n{appliance}:")  # Print the name of the appliance being analyzed.
    
    # Loop through each unique date in the dataset to check appliance usage on each day.
    for date in dtNewDataset['Date'].unique():
        # Identify the specific hours during which the appliance was running on that day.
        hours_running = dtNewDataset[
            (dtNewDataset['Date'] == date) & (dtNewDataset[appliance] > 0)
        ]['Time'].tolist()
        
        # If the appliance ran during any hours, display the hours it was active.
        if hours_running:
            print(f"  {date} - Run at hour(s): {', '.join(map(str, hours_running))}")
        else:
            # If the appliance was not used that day, indicate it was not running.
            print(f"  {date} - Not running")

# Calculate the total energy usage (in kWh) for each day by summing 'TotalUsagekWh' for each date.
total_usage_per_day = dtNewDataset.groupby('Date')['TotalUsagekWh'].sum()

# Display daily total energy usage.
print("\nTotal Energy Usage for Each Day:")
for date, total_usage in total_usage_per_day.items():
    print(f"Date: {date}, Total Usage: {total_usage:.2f} kWh")  # Format total usage to two decimal places.

# Calculate the cumulative energy usage across all days by summing daily totals.
total_usage_all_days = total_usage_per_day.sum()
# Display the overall energy usage across the analyzed period.
print(f"\nTotal Energy Usage Across All Days: {total_usage_all_days:.2f} kWh")


# In[29]:


# Genetic Algorithm
# Importing the random module to generate random values for initialization, crossover, and mutation
import random 

# Set a fixed random seed for reproducibility
random.seed(42)

# Aggregate hourly data to weekly total
# Summing up the hourly usage to calculate total weeklyenergy usage
weekly_total_usage = dtNewDataset["TotalUsagekWh"].sum()

# Scale to monthly usage
weekly_to_monthly_factor = 4.33  # Approximate number of weeks in a month
monthly_usage_estimation = weekly_total_usage * weekly_to_monthly_factor  # Scaling weekly usage to monthly usage

# Seasonal factors for Bahrain
seasonal_factors = {  # Adjusting monthly energy usage to reflect seasonal variations
    "January": 0.8, "February": 0.8, "March": 0.9, "April": 1.0,
    "May": 1.2, "June": 1.5, "July": 1.6, "August": 1.5,
    "September": 1.3, "October": 1.1, "November": 0.9, "December": 0.8,
}

# Historical baseline data
historical_data = {  # Energy usage values from historical records for each month
    "January": 2132.0,
    "February": 1990.0,
    "March": 2298.0,
    "April": 2966.0,
    "May": 4087.0,
    "June": 6444.0,
    "July": 8711.0,
    "August": 7188.0,
    "September": 7159.0,
    "October": 6441.0,
    "November": 4021.0,
    "December": 2721.0,
}

# Genetic Algorithm Parameters
population_size = 50  # Number of solutions in each generation
generations = 200  # Number of iterations to optimize the solutions
mutation_rate = 0.1  # Probability of mutating a solution

# Fitness function with penalty for increasing trends
def fitness_function(solution, baseline):
    total_usage = sum(solution)  # Total energy usage across all months
    penalty = sum(max(0, solution[i] - baseline[i]) for i in range(len(solution)))  # Penalty for usage exceeding baseline
    return total_usage + penalty  # Fitness value (lower is better)

# Initialize population with a decreasing trend
def initialize_population(size, year, baseline):
    decrease_factor = 1 - (year - 1) * 0.05  # Decrease energy usage by 5% for each subsequent year
    population = []
    for _ in range(size):  # Generate the initial population
        individual = [
            random.uniform(
                baseline[i] * seasonal_factors[month] * 0.8 * decrease_factor,  # Minimum value for each month
                baseline[i] * seasonal_factors[month] * 1.2 * decrease_factor,  # Maximum value for each month
            )
            for i, month in enumerate(historical_data.keys())  # Loop over each month
        ]
        population.append(individual)  # Add the individual to the population
    return population

# Selection
def select(population, fitness_scores):
    return random.choices(population, weights=fitness_scores, k=2)  # Select two parents based on fitness scores

# Crossover
def crossover(parent1, parent2):
    crossover_point = random.randint(0, len(parent1) - 1)  # Random point to split parents
    child = parent1[:crossover_point] + parent2[crossover_point:]  # Combine parts of both parents to create a child
    return child

# Mutation with controlled variance
def mutate(individual, baseline):
    if random.random() < mutation_rate:  # Apply mutation based on probability
        mutation_index = random.randint(0, len(individual) - 1)  # Randomly select a month to mutate
        individual[mutation_index] = random.uniform(
            baseline[mutation_index] * 0.8, baseline[mutation_index] * 1.2  # New value within a controlled range
        )
    return individual

# Genetic Algorithm
def genetic_algorithm(year, baseline):
    population = initialize_population(population_size, year, baseline)  # Initialize population for the given year
    for generation in range(generations):  # Run optimization for the specified number of generations
        fitness_scores = [1 / (fitness_function(ind, baseline) + 1e-6) for ind in population]  # Calculate fitness for each
        new_population = []
        for _ in range(population_size // 2):  # Generate new population
            parent1, parent2 = select(population, fitness_scores)  # Select two parents
            child1 = mutate(crossover(parent1, parent2), baseline)  # Create first child with mutation
            child2 = mutate(crossover(parent2, parent1), baseline)  # Create second child with mutation
            new_population.extend([child1, child2])  # Add children to the new population
        population = new_population  # Update population
    best_individual = min(population, key=lambda ind: fitness_function(ind, baseline))  # Select the best individual
    return best_individual

# Run the Genetic Algorithm for 5 Years
predictions = {}
baseline = list(historical_data.values())  # Convert historical data to a list for easy indexing
for year in range(1, 6):  # Run the genetic algorithm for each of the 5 years
    predictions[f"Year {year}"] = genetic_algorithm(year, baseline)  # Store the best prediction for the year
    baseline = predictions[f"Year {year}"]  # Update baseline for the next year

# Visualize Predictions
months = list(historical_data.keys())  # Get the month names
plt.figure(figsize=(12, 8))  # Create a new figure for plotting
for year, prediction in predictions.items():  # Plot each year's predictions
    plt.plot(months, prediction, marker='o', label=f"{year} Prediction")

# Baseline for comparison
baseline = list(historical_data.values())  # Reset baseline to historical data for comparison
plt.plot(months, baseline, marker='x', linestyle='--', label="Baseline Data (Year 0)")  # Plot the baseline data

plt.title("5-Year Predicted Monthly Energy Usage")  # Set plot title
plt.xlabel("Month")  # Label for the x-axis
plt.ylabel("Energy Usage (kWh)")  # Label for the y-axis
plt.legend()  # Add legend to the plot
plt.grid()  # Add grid to the plot
plt.show()  # Display the plot


# In[30]:


# Print Results with Annual Total
baseline_total_usage = sum(historical_data.values())  # Calculate the total usage from the baseline data
print(f"\nBaseline Total Annual Usage = {baseline_total_usage:.2f} kWh")  # Print the baseline total usage

for year, prediction in predictions.items():
    print(f"\n{year} Predictions:")
    annual_usage = 0  # Initialize annual usage for the current year
    for month, usage in zip(months, prediction):  # Loop through each month and its usage
        print(f"{month}: Usage = {usage:.2f} kWh")  # Print the monthly usage
        annual_usage += usage  # Accumulate the annual usage
    print(f"Total Annual Usage = {annual_usage:.2f} kWh")  # Print the total annual usage for the year


# In[31]:


# Genetic Algorithm
# Importing the random module to generate random values for initialization, crossover, and mutation
import random

# Set a fixed random seed for reproducibility
random.seed(42)

# Aggregate hourly data to weekly total
weekly_total_usage = dtNewDataset["TotalUsagekWh"].sum()

# Scale to monthly usage
weekly_to_monthly_factor = 4.33  # Approximate number of weeks in a month
monthly_usage_estimation = weekly_total_usage * weekly_to_monthly_factor  # Scaling weekly usage to monthly usage

# Seasonal factors for Bahrain
seasonal_factors = {  # Adjusting monthly energy usage to reflect seasonal variations
    "January": 0.8, "February": 0.8, "March": 0.9, "April": 1.0,
    "May": 1.2, "June": 1.5, "July": 1.6, "August": 1.5,
    "September": 1.3, "October": 1.1, "November": 0.9, "December": 0.8,
}

# Historical baseline data
historical_data = {  # Energy usage values from historical records for each month
    "January": 2132.0,
    "February": 1990.0,
    "March": 2298.0,
    "April": 2966.0,
    "May": 4087.0,
    "June": 6444.0,
    "July": 8711.0,
    "August": 7188.0,
    "September": 7159.0,
    "October": 6441.0,
    "November": 4021.0,
    "December": 2721.0,
}

# Bahrain's average annual electricity usage (2021)
target_annual_usage = 19597  # kWh
monthly_target_usage = target_annual_usage / 12

# Genetic Algorithm Parameters
population_size = 50  # Number of solutions in each generation
generations = 1000  # Increased generations for deeper optimization
mutation_rate = 0.1  # Mutation rate for controlled adjustments
min_threshold = 0.3  # Minimum threshold as a fraction of Bahrain's monthly average

# Fitness function for matching the target annual usage
def fitness_function(solution):
    total_usage = sum(solution)  # Total energy usage across all months
    deviation_penalty = abs(total_usage - target_annual_usage)  # Penalize deviation from the target
    return deviation_penalty  # Fitness value (lower is better)

# Initialize population
def initialize_population(size, baseline):
    population = []
    for _ in range(size):  # Generate the initial population
        individual = [
            random.uniform(
                max(baseline[i] * seasonal_factors[month] * 0.5, 0.3 * baseline[i]),  # Minimum value (threshold > 0)
                baseline[i] * seasonal_factors[month] * 0.9,  # Maximum value (90% of baseline)
            )
            for i, month in enumerate(historical_data.keys())  # Loop over each month
        ]
        population.append(individual)  # Add the individual to the population
    return population

# Selection
def select(population, fitness_scores):
    return random.choices(population, weights=[1 / f for f in fitness_scores], k=2)  # Select two parents based on fitness scores

# Crossover
def crossover(parent1, parent2):
    crossover_point = random.randint(0, len(parent1) - 1)  # Random point to split parents
    child = parent1[:crossover_point] + parent2[crossover_point:]  # Combine parts of both parents to create a child
    return child

# Mutation with controlled variance
def mutate(individual):
    if random.random() < mutation_rate:  # Apply mutation based on probability
        mutation_index = random.randint(0, len(individual) - 1)  # Randomly select a month to mutate
        individual[mutation_index] = random.uniform(
            individual[mutation_index] * 0.8, individual[mutation_index] * 1.2  # New value within a controlled range
        )
    return individual

# Genetic Algorithm for optimized yearly schedule
def optimize_schedule(baseline):
    population = initialize_population(population_size, baseline)  # Initialize population
    for generation in range(generations):  # Run optimization for the specified number of generations
        fitness_scores = [fitness_function(ind) for ind in population]  # Calculate fitness for each
        new_population = []
        for _ in range(population_size // 2):  # Generate new population
            parent1, parent2 = select(population, fitness_scores)  # Select two parents
            child1 = mutate(crossover(parent1, parent2))  # Create first child with mutation
            child2 = mutate(crossover(parent2, parent1))  # Create second child with mutation
            new_population.extend([child1, child2])  # Add children to the new population
        population = new_population  # Update population
    best_individual = min(population, key=fitness_function)  # Select the best individual
    return best_individual

# Run the Genetic Algorithm
baseline = list(historical_data.values())  # Convert historical data to a list for easy indexing
optimized_schedule = optimize_schedule(baseline)  # Optimize the schedule

# Visualize Optimized Schedule
months = list(historical_data.keys())  # Get the month names
plt.figure(figsize=(14, 8))  # Set a larger figure size (width=14, height=8)
plt.bar(months, optimized_schedule, color='skyblue', label="Optimized Schedule")  # Bar chart for optimized schedule
plt.plot(months, baseline, marker='x', linestyle='--', color='red', label="Baseline Data (Year 0)")  # Plot baseline data

plt.title("Optimized Yearly Energy Usage Schedule", fontsize=16)  # Larger title
plt.xlabel("Month", fontsize=14)  # Larger x-axis label
plt.ylabel("Energy Usage (kWh)", fontsize=14)  # Larger y-axis label
plt.xticks(fontsize=12)  # Larger x-axis tick labels
plt.yticks(fontsize=12)  # Larger y-axis tick labels
plt.legend(fontsize=12)  # Larger legend
plt.grid(axis='y')  # Add grid lines for y-axis
plt.tight_layout()  # Adjust layout to avoid clipping
plt.show()  # Display the plot

# Print Results with Annual Total
print(f"\nBaseline Total Annual Usage (Bahrain Average): {target_annual_usage:.2f} kWh")
print("\nOptimized Yearly Schedule:")
annual_usage = 0
for month, usage in zip(months, optimized_schedule):  # Loop through each month and its usage
    print(f"{month}: Usage = {usage:.2f} kWh")  # Print the monthly usage
    annual_usage += usage  # Accumulate the annual usage
print(f"Total Optimized Annual Usage = {annual_usage:.2f} kWh")  # Print the total annual usage for the optimized schedule


# In[ ]:




